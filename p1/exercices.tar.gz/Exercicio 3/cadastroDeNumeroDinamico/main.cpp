#include "cadastro.h"
int main() {
    menu();
    return 0;
}