void menu();
void cadastrarNumero();
void exibirNumerosCadastrados();
void mostraQuantidadeDeNumerosCadastrados();
void removerUltimoNumero();