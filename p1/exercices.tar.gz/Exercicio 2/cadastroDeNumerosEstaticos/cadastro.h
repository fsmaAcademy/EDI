void menu();
void exibirNumeros(int vetor[]);
void exibirNumerosPares(int vetor[]);
void exibirNumerosImpares(int vetor[]);
void cadastraNumeros(const int *numeros);
