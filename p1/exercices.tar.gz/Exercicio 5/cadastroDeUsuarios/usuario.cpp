#include <iostream>
#include <stdio_ext.h>
#include "usuario.h"

using namespace std;

int quantidadeDeUsuarios = 0;
Usuario *_usuario;

void sair() {
    free(_usuario);
}

void removerUltimoNumero() {
    quantidadeDeUsuarios--;
    cout << "Usuário removido com sucesso!" << endl;
}

void numeroDeUsuariosCadastrados() {
    cout << "Número de usuários cadastrados: " << quantidadeDeUsuarios << endl;
}

void listarUsuarios() {

    if (quantidadeDeUsuarios == 0) cout << "Nenhum usuário cadastrado." << endl;

    for (int i = 0; i < quantidadeDeUsuarios; ++i) {
        cout << "Nome: " << _usuario[i].nome << endl;
        cout << "RG: " << _usuario[i].rg << endl;
        cout << "CPF: " << _usuario[i].cpf << endl;
        cout << "Endereço : " << _usuario[i].endereco << endl;
        cout << "---------------------" << endl;
    }

}

void cadastrarUsuario() {

    Usuario *usuario;

    usuario = _usuario;

    if(quantidadeDeUsuarios > 0) usuario = (Usuario *) realloc(usuario, quantidadeDeUsuarios * sizeof(Usuario));
    else usuario = (Usuario *) malloc(sizeof(Usuario));

    if(!usuario) {
        cout << "Exaustão de memória!" << endl;
        exit(1);
    }

    __fpurge(stdin);
    cin.clear();
    cout << "Digite seu nome: ";
    cin.getline(usuario[quantidadeDeUsuarios].nome, 100);

    __fpurge(stdin);
    cin.clear();
    cout << "Digite seu RG: ";
    cin.getline(usuario[quantidadeDeUsuarios].rg, 9);

    __fpurge(stdin);
    cin.clear();
    cout << "Digite seu CPF: ";
    cin.getline(usuario[quantidadeDeUsuarios].cpf, 11);

    __fpurge(stdin);
    cin.clear();
    cout << "Digite seu Endereço: ";
    cin.getline(usuario[quantidadeDeUsuarios].endereco, 100);

    _usuario = usuario;

    quantidadeDeUsuarios++;

}
