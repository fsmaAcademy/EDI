void programa();
int converteAscii(char digito);

