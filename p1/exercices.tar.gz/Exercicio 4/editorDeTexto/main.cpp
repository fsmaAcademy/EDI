#include "ascii.h"
int main() {
    programa();
    return 0;
}

