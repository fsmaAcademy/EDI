#include <iostream>
#include <stdio_ext.h>

using namespace std;

void topDoMenuPrincipal() {
    cout << "-------------------------------------" << endl;
    cout << "------------MENU PRINCIPAL-----------" << endl;
    cout << "-------------------------------------" << endl;
}

void topoListaLivros() {
    cout << "-----------------------------------------" << endl;
    cout << "------------LIVROS CADASTRADOS-----------" << endl;
    cout << "-----------------------------------------" << endl;
}

void topoCadastraLivros() {
    cout << "--------------------------------------" << endl;
    cout << "------------CADASTRAR LIVRO-----------" << endl;
    cout << "--------------------------------------" << endl;
}

void topoTabelaDeLivros() {
    char format = ' ';
    printf("|========================================================================================|\n");
    printf("| TÍTULO %-23c | AUTOR %-14c | CÓDIGO %-3c | ANO DE PUBL. %-4c |\n",format, format, format, format);
    printf("|========================================================================================|\n");
}