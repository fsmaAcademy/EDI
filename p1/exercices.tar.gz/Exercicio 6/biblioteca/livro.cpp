#include <iostream>
#include <stdio_ext.h>
#include <cstring>
#include "livro.h"
#include "mensagens.h"

void menuLivro() {

    char escolha = ' ';

    topDoMenuPrincipal();

    cout << "1. Cadastrar livro" << endl;
    cout << "2. Consultar todos os livros" << endl;
    cout << "3. Sair" << endl;
    cout << "Digite uma das opções: ";
    cin >> escolha;

    switch (escolha) {
        case '3':
            return;
        case '1':
            cadastarLivro();
            break;
        case '2':
            listarLivros();
            break;
        default:
            cout << "Opção inválida. Tente Novamente..." << endl;
    }

    cout << "Pressione Enter tecla para continuar..." << endl;
    __fpurge(stdin);
    getchar();

    menuLivro();
}

void listarLivros() {

    char ch;

    topoListaLivros();
    FILE *arq = fopen("livros", "r");
    if(arq == NULL) {
        cout << "Erro na abertura do arquivo." << endl;
        return;
    }

    topoTabelaDeLivros();

    ch = getc(arq);
    while (ch != EOF) {
        putchar(ch);
        ch = getc(arq);
    }
    cout << endl << endl << endl;

    fclose(arq);
}

void cadastarLivro() {

    topoCadastraLivros();

    book livro;

    __fpurge(stdin);
    cin.clear();
    cout << "Título: ";
    cin.getline(livro.titulo, 100);

    __fpurge(stdin);
    cin.clear();
    cout << "Autor: ";
    cin.getline(livro.autor, 100);

    __fpurge(stdin);
    cout << "Código do Livro: ";
    cin >> livro.codigo;

    __fpurge(stdin);
    cout << "Ano de publicação: ";
    cin >> livro.anoDePublicacao;

    insereLivro(&livro);

    cout << "Cadastro realizado com sucesso!" << endl;
}

void insereLivro(book *livro) {

    FILE *arq;

    if((arq = fopen("livros", "a")) == NULL) {
        cout << "Erro ao criar o arquivo";
        return;
    }

    fprintf(arq, "| %-30s | %-20s | %-10d | %-17d |\n",
            livro->titulo,
            livro->autor,
            livro->codigo,
            livro->anoDePublicacao
    );

    fclose(arq);

}

