#include <string>
using namespace std;
typedef struct book {
    char titulo[101];
    char autor[101];
    int codigo;
    int anoDePublicacao;
} book;

void menuLivro();
void cadastarLivro();
void insereLivro(book *livro);
void listarLivros();

